-- ====== CLUBS ======
-- SELECT
SELECT * FROM Clubs;

-- INSERT
INSERT INTO Clubs (clubName, description, budget)
VALUES (@clubNameInput, @descriptionInput, @budgetInput);

-- UPDATE
UPDATE Clubs
SET clubName = @clubNameInput,
    description = @descriptionInput,
    budget = @budgetInput
WHERE clubID = @clubIDInput;

-- DELETE
DELETE FROM Clubs WHERE clubID = @clubIDInput;

-- ====== STUDENTS ======
SELECT * FROM Students;

INSERT INTO Students (firstName, lastName, email)
VALUES (@firstNameInput, @lastNameInput, @emailInput);

UPDATE Students
SET firstName = @firstNameInput,
    lastName = @lastNameInput,
    email = @emailInput
WHERE studentID = @studentIDInput;

DELETE FROM Students WHERE studentID = @studentIDInput;

-- ====== EVENTS ======
SELECT e.eventID, e.eventName, e.eventDate, e.location, c.clubName
FROM Events e
JOIN Clubs c ON e.clubID = c.clubID;

INSERT INTO Events (eventName, eventDate, location, clubID)
VALUES (@eventNameInput, @eventDateInput, @locationInput, @clubIDInput);

UPDATE Events
SET eventName = @eventNameInput,
    eventDate = @eventDateInput,
    location = @locationInput,
    clubID = @clubIDInput
WHERE eventID = @eventIDInput;

DELETE FROM Events WHERE eventID = @eventIDInput;

-- ====== FUNDING REQUESTS ======
SELECT f.requestID, f.amountRequested, f.status, f.submittedDate, e.eventName
FROM FundingRequests f
JOIN Events e ON f.eventID = e.eventID;

INSERT INTO FundingRequests (amountRequested, status, submittedDate, eventID)
VALUES (@amountInput, @statusInput, @submittedDateInput, @eventIDInput);

UPDATE FundingRequests
SET amountRequested = @amountInput,
    status = @statusInput,
    submittedDate = @submittedDateInput,
    eventID = @eventIDInput
WHERE requestID = @requestIDInput;

DELETE FROM FundingRequests WHERE requestID = @requestIDInput;

-- ====== EVENT ATTENDANCE ======
SELECT ea.attendanceID, s.firstName, s.lastName, e.eventName, ea.checkInTime
FROM EventAttendance ea
JOIN Students s ON ea.studentID = s.studentID
JOIN Events e ON ea.eventID = e.eventID;

INSERT INTO EventAttendance (checkInTime, studentID, eventID)
VALUES (@checkInTimeInput, @studentIDInput, @eventIDInput);

UPDATE EventAttendance
SET checkInTime = @checkInTimeInput,
    studentID = @studentIDInput,
    eventID = @eventIDInput
WHERE attendanceID = @attendanceIDInput;

DELETE FROM EventAttendance WHERE attendanceID = @attendanceIDInput;

