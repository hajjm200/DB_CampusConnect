const express = require('express');
const app = express();
const path = require('path');
const db = require('./db-connector.js');

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname)));

// TEST DB CONNECTION
app.get('/test-db', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT 1 + 1 AS solution;');
    res.json({ solution: rows[0].solution });
  } catch (err) {
    res.status(500).send(err);
  }
});

/* -----------------------------
   RESET DATABASE (CALL SP)
----------------------------- */
app.get('/reset', async (req, res) => {
  try {
    await db.query("CALL reset_database();");
    res.send("Database has been RESET successfully.");
  } catch (err) {
    console.log(err);
    res.status(500).send("RESET failed.");
  }
});

/* -----------------------------
   API SELECT ROUTES
----------------------------- */
app.get('/api/clubs', async (req, res) => {
  const [rows] = await db.query("SELECT * FROM Clubs;");
  res.json(rows);
});

app.get('/api/students', async (req, res) => {
  const [rows] = await db.query("SELECT * FROM Students;");
  res.json(rows);
});

app.get('/api/events', async (req, res) => {
  const [rows] = await db.query("SELECT * FROM Events;");
  res.json(rows);
});

app.get('/api/funding', async (req, res) => {
  const [rows] = await db.query("SELECT * FROM FundingRequests;");
  res.json(rows);
});

app.get('/api/attendance', async (req, res) => {
  const [rows] = await db.query("SELECT * FROM EventAttendance;");
  res.json(rows);
});

/* -----------------------------
   DELETE ROUTE (Required)
----------------------------- */
app.delete('/api/students/:id', async (req, res) => {
  const id = req.params.id;
  await db.query("DELETE FROM Students WHERE studentID = ?", [id]);
  res.sendStatus(200);
});

/* -----------------------------
   SERVER LISTEN
----------------------------- */
const PORT = 8302;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Campus Connect running at http://classwork.engr.oregonstate.edu:${PORT}`);
});

